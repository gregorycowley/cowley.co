<?php

define("PE_THEME_NAME",'Brandspace');

// bootstrap the framework
define("PE_THEME_PATH",dirname( __FILE__));
require("framework/php/boot.php");

?>
