<!-- no posts -->
<div id="main">
	<br/>
	<p><?php e__pe("Your search returned no results. Please try a different keyword or browse using categories & tags"); ?></p>
</div>