<?php

class PeThemeFormElementUploadLink extends PeThemeFormElementUpload {

	protected function addTemplateValues(&$data) {
		$data["[UPCLASS]"] = "";

	}

}

?>
