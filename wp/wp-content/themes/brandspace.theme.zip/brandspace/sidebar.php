
<!--sidebar-->

<aside class="span4 sidebar">
	
	<div class="sidebar-wrap-inner">
		<?php peTheme()->sidebar->show("default",!(is_single() || is_page())); ?>
	</div>
 
</aside>


<!--end sidebar-->